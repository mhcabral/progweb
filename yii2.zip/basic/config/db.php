<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=icomp',
    'username' => 'root',
    'password' => 'kx8964t',
    'charset' => 'utf8',
];

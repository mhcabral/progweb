<?php

namespace app\models;

use Yii;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "aluno".
 *
 * @property integer $id
 * @property integer $matricula
 * @property string $nome
 * @property string $sexo
 * @property integer $id_curso
 * @property integer $ano_ingresso
 *
 * @property Curso $idCurso
 */



class Aluno extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'aluno';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['matricula', 'id_curso', 'ano_ingresso','nome', 'sexo'],'required','message'=>'Este campo é obrigatório'],
            [['matricula', 'id_curso', 'ano_ingresso'], 'integer','message'=>'Este campo deve ser preenchido com números'],
            [['nome'], 'string', 'max' => 200,'message'=>'Este campo deve conter no máximo 200 caracteres'],
            [['sexo'], 'string', 'max' => 10,'message'=>'Este campo deve conter no máximo 1 caractere']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'matricula' => 'Matricula',
            'nome' => 'Nome',
            'sexo' => 'Sexo',
            'id_curso' => 'Curso de Graduação',
            'idCurso.nome' => 'Curso de Graduação',
            'ano_ingresso' => 'Ano Ingresso',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdCurso()
    {
        return $this->hasOne(Curso::className(), ['id' => 'id_curso']);
    }

    public function getNumAlunos($ano_ingresso)
    {
        return $this->find()->where('ano_ingresso='.$ano_ingresso)->count();
    }

    public function getArraySexo()
    {
        return array('Masculino'=>'Masculino','Feminino'=>'Feminino');
    }

    public function getArrayCurso()
    {
        return ArrayHelper::map(Curso::find()->all(), 'id', 'nome');
    }

    public function afterFind() {

        $this->nome = strtolower($this->nome);
        $aux = explode(" ",$this->nome);
        $aux2 = null;
        for ($i=0; $i < count($aux); $i++) {
     
            // Tratar cada palavra do nome
            if ($aux[$i] == "de" or $aux[$i] == "da" or $aux[$i] == "e" or $aux[$i] == "dos" or $aux[$i] == "do") {
                $aux2 .= $aux[$i].' '; // Se a palavra estiver dentro das complementares mostrar toda em minúsculo
            }else {
                $aux2 .= ucfirst($aux[$i]).' '; // Se for um nome, mostrar a primeira letra maiúscula
            }
        }
        $this->nome = $aux2;

        if($this->sexo == 'M')
            $this->sexo = 'Masculino';
        else if($this->sexo == 'F')
            $this->sexo = 'Feminino';


        return parent::afterFind();
    }

    public function beforeSave(){
        if($this->sexo == 'Masculino')
            $this->sexo = 'M';
        else if($this->sexo == 'Feminino')
            $this->sexo = 'F';
    }
}
